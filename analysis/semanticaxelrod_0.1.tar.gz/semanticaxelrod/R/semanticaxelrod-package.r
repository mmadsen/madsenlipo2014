#' semanticaxelrod
#'
#' @name semanticaxelrod
#' @docType package
NULL
